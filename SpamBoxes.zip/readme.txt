To start the spam run SpamStart.exe to stop the spam Run SpamStop.exe

It might get laggy when u run it many times 

but for me you can do this on main but dont run it many times unless u want it laggy


Made and developed by reeps



You can like edit the exe i accept it since im a noob. ):

You can trick it with your friends just rename the exe to make it like its 100% legit

good luck (:




--- reeps


minecraft user : Steveie

roblox user: itsthereeps